// Khai báo các chân nối với đèn LED
const int ledRed = 10;
const int ledYellow = 9;
const int ledGreen = 8;

void setup() {
  // Thiết lập các chân là ngõ ra (OUTPUT)
  pinMode(ledRed, OUTPUT);
  pinMode(ledYellow, OUTPUT);
  pinMode(ledGreen, OUTPUT);
}

void loop() {
  // 1. Bật đèn Xanh, tắt Đỏ và Vàng trong 3 giây (3000ms)
  digitalWrite(ledGreen, HIGH);
  digitalWrite(ledYellow, LOW);
  digitalWrite(ledRed, LOW);
  delay(3000); 

  // 2. Bật đèn Vàng, tắt Xanh và Đỏ trong 1 giây (1000ms)
  digitalWrite(ledGreen, LOW);
  digitalWrite(ledYellow, HIGH);
  digitalWrite(ledRed, LOW);
  delay(1000); 

  // 3. Bật đèn Đỏ, tắt Xanh và Vàng trong 3 giây (3000ms)
  digitalWrite(ledGreen, LOW);
  digitalWrite(ledYellow, LOW);
  digitalWrite(ledRed, HIGH);
  delay(3000); 
}