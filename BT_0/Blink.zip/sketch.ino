void setup() {
  // Khởi tạo chân LED tích hợp sẵn (chân 13) là đầu ra
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH);  // Bật đèn LED (cấp điện áp mức cao)
  delay(1000);                      // Chờ 1000 mili giây (1 giây)
  digitalWrite(LED_BUILTIN, LOW);   // Tắt đèn LED (cấp điện áp mức thấp)
  delay(1000);                      // Chờ 1 giây
}