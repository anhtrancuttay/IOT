/*
 * Created by ArduinoGetStarted.com
 *
 * This example code is in the public domain
 *
 * Tutorial page: https://arduinogetstarted.com/tutorials/arduino-lm35-temperature-sensor
 */

// #define ADC_VREF_mV    5000.0 // in millivolt
// #define ADC_RESOLUTION 1024.0
// #define PIN_LM35       A0

void setup(){
  Serial.begin(9600);
}

void loop(){
  int sensorValue = analogRead(A0);
  Serial.println(sensorValue);
  delay(1);
}

